
package coe318.lab8;


public class Resistor {
    private int firstNode;
    private int secondNode;
    private double resistance;
    // i will be used to increment the elementNum each time an object is created 
    private static int i = 1;
    private int elementNum;
    
    
    public Resistor(int firstNode, int secondNode, double resistance){
        this.firstNode = firstNode;
        this.secondNode = secondNode;
        this.resistance = resistance;
        //increment i after setting elementNum equal to it
        //keeps track of how many resistor elements have been created, important for the spice command
        this.elementNum = i++;
        
    } 
    
    //to string method for spice output
    @Override
    public String toString(){
        return "R" + elementNum + " " + firstNode + " " + secondNode + " " + resistance;
    }
}
