
package coe318.lab8;
import java.util.Scanner;

///methods to be implemented in the circuit class
public class CircuitUI implements CircuitInterface {
    //scans input from the user
    private Scanner user = new Scanner(System.in);
    private Circuit circuit;
    
    @Override
    public void setCircuit(Circuit circuit){
        this.circuit = circuit;
    }

    @Override
    public void userDone(){
        System.out.println("\nAll Done");
    }
    
    @Override
    public void spiceDisplay(){
        //print out the spice interface to the user when prompted
        System.out.println(circuit.getSpice());
    }
    
    @Override
    public String getUserInput() { 
        //trim the white space from the beginning and end of user input for formatting purposes
        return user.nextLine().trim();
    }
    
}
