
package coe318.lab8;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class VoltageTest {
    
    public VoltageTest() {
    }
   
    @Test
    public void testGetVolt() {
        System.out.println("getVolt");
        Voltage v = new Voltage(0,1,5.5);
        double expResult = 5.5;
        double result = v.getVolt();
        assertEquals(expResult, result, 0);
    }

    @Test
    public void testToString() {
        System.out.println("toString");
        Voltage v = new Voltage(0,1,2.3);
        int elementNum = 1;
        String expResult = "V1 0 1 DC 2.3";
        String result = v.toString();
        assertEquals(expResult, result);
    }
    
}
